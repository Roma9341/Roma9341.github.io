A Pen created at CodePen.io. You can find this one at https://codepen.io/dudleystorey/pen/kiajB.

 Using CSS 3D transforms, and just a bit of Javascript. More information [on my blog](http://thenewcode..com/690/Simple-CSS-3D-Carousel-Gallery).